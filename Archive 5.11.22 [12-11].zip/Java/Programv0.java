public class Programv0 {
    // Write a program that counts to 10
    public static void main(String[] args) {
        int i = 0;
        while (i < 10) {
            System.out.println(i);
            i = i + 1;
        }
    }
}
// This shows a test program that counts to 10. The program is copyleft [C] - Flames Co. Soft 20XX